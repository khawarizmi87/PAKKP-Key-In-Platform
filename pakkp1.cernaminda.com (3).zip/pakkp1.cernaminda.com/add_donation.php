<?php
include 'connection.php';
include ('functions.php');   
$id = isset($_GET['id']) ? $_GET['id'] : '';
$fullName=getFullName();
$Region=getRegion();
$sql1 = "SELECT * FROM donor where id = '$id'"; 
$result1 = mysqli_query($conn, $sql1) or die(mysqli_error($conn));
while($row = mysqli_fetch_array($result1)){
$id         = $row['id'];
$Name 		= $row['Name'];
$acc_Name 	= $row['acc_Name'];
$KP 		= $row['KP'];
$acc_No 	= $row['acc_No'];
$Bank 		= $row['Bank'];
$Add1 		= $row['Add1'];
$Add2 		= $row['Add2'];
$Poscode	= $row['Poscode'];
$Town 		= $row['Town'];
$State 		= $row['State'];
$phone_No 	= $row['phone_No'];
$Wakil 		= $row['Wakil'];
$Gender 	= $row['Gender'];
$Program 	= $row['Program'];

}

?>

<!DOCTYPE html>
<html>
<head>

</head>
<body>
<?php    
if(isset($_POST['Donate_btn'])) { 

	//$date 			= date('Y-m-d', strtotime($_POST['receipt_Date']));
	$id             = e($_POST['id']); 
	$newdate        = e($_POST['receipt_Date']);
	$Name 			= e($_POST['Name']);
	$acc_Name 		= e($_POST['acc_Name']);
	$KP 			= e($_POST['KP']);
	$acc_No 		= e($_POST['acc_No']);
	$Bank 			= e($_POST['Bank']);
	$Que			= e($_POST['Que']);
	$Donation 		= e($_POST['Donation']);
	$Ref			= e($_POST['Ref']);
	$Add1 			= e($_POST['Add1']);
	$Add2 			= e($_POST['Add2']);
	$Poscode		= e($_POST['Poscode']);
	$Town 			= e($_POST['Town']);
	$State 			= e($_POST['State']);
	$phone_No 		= e($_POST['phone_No']);
	$Wakil 			= e($_POST['Wakil']);
	$Gender 		= e($_POST['Gender']);
	$in_Charge 		= e($_POST['in_Charge']);
	$Program 		= e($_POST['Program']);
	$Derma			= e($_POST['Derma']);
	$Pegawai_D		= e($_POST['Pegawai_D']);
            
            // checking empty fields
	
	$search = "SELECT * FROM donation WHERE Rujukan ='$Ref'";
	$result = mysqli_query($db,$search);
	if (mysqli_num_rows($result) > 0){
	array_push($errors, "Ref already exist"); 	
	}
	if ($newdate == '') { 
	array_push($errors, "Tarikh Terima Borang Sukarelawan is required"); 
	}
	else{ 
	$date = date('Y-m-d', strtotime($newdate));
	}
	if (empty($Name)) { 
		array_push($errors, "Name required"); 
	}
	if (empty($KP)) { 
		array_push($errors, "KP is required"); 
	}
	if (empty($acc_No)) { 
		array_push($errors, "Acc.No is required"); 
	}
	if (empty($Bank)) {
		array_push($errors, "Bank does not exist");
	}
	if (empty($Que)) {
		array_push($errors, "Que is required");
	}
	if (empty($Donation)) {
		array_push($errors, "Donation is required");
	}
	if (empty($Ref)) {
		array_push($errors, "Ref is required");
	}
	$Code = substr($Ref, -4);
	$newCode = substr($Ref, -5);
	$neoCode = substr($Ref,-6);
	if ($Donation == "250" && $newCode != "WDPDr"){
		array_push($errors, "Donation and Ref is different");
	}
	if ($Donation == "1000" && $Code != "WDPk"){
		array_push($errors, "Donation and Ref is different");
	}
	if ($Donation == "5000" && $newCode != "WDPvk"){
		array_push($errors, "Donation and Ref is different");
	}
	if ($Donation == "10000" && $newCode != "WDPxk"){
		array_push($errors, "Donation and Ref is different");
	}
	if ($Donation == "25000" && $neoCode != "WDPDrh"){
		array_push($errors, "Donation and Ref is different");
	}
	if ($Donation == "100000" && $Code != "WDPC"){
		array_push($errors, "Donation and Ref is different");
	}
	if (empty($Add1)) {
		array_push($errors, "Add1 is required");
	}
	if (empty($Poscode)) {
		array_push($errors, "Poscode is required");
	}
	if (empty($Town)) {
		array_push($errors, "Town is required");
	}
	if (empty($State)) {
		array_push($errors, "State is required");
	}
	if (empty($Poscode)) {
		array_push($errors, "Poscode is required");
	}
	if (empty($Wakil)) {
		array_push($errors, "Wakil is required");
	}
	if (empty($in_Charge)) {
		array_push($errors, "Person Incharge is required");
	}
	if (empty($Gender)) {
		array_push($errors, "Gender is required");
	}
	if (empty($Derma)) {
		array_push($errors, "Wang Derma is required");
	}
	if (empty($Program)) {
		array_push($errors, "Program is required");
	}
	if (empty($Pegawai_D)) {
		array_push($errors, "Pegawai Data is not captured");
	}
	
	if (count($errors) == 0){
	    
/*	    $sql3 = "UPDATE `donor` SET `Name`='$Name', `acc_Name`='$acc_Name', `KP` ='$KP', `acc_No` = '$acc_No', `Bank` = '$Bank', `Add1` = '$Add1', `Add2` = ' $Add2', `Poscode` = '$Poscode', `Town` = '$Town', `State` = '$State', `phone_No` ='$phone_No', `Wakil` ='$Wakil', `Gender`  = '$Gender', `in_Charge` = '$in_Charge', `Program` ='$Program'
                 WHERE `donor`.`KP` = '$KP'";
        $result3 = mysqli_query($db, $sql3);
        if($result3){
		   echo "<script language='Javascript'> 
		   alert('data updated successfully');
		   </script>";
		}
		else{
		     die('Error: ' . mysqli_error($db));
		}*/
        
		$sql2 = "INSERT INTO donation ( `DONORID`, `Tarikh Terima Borang Sukarelawan`,`Name`,`Account Name`,`KP`,`Que`, `Donation`, `Rujukan`, `No.Acc`, `Bank`, `Add 1`, `Add 2`, `Poscode`, `Town`, `State`, `Telefon`, `Wakil`, `Gender`, `Person Incharge`, `Wang Derma`,`Ref`, `Pegawai Data` ) 
				VALUES ('$id','$date','$Name','$acc_Name','$KP', '$Que', '$Donation', '$Ref', '$acc_No', '$Bank', '$Add1', '$Add2', '$Poscode', '$Town', '$State', '$phone_No', '$Wakil', '$Gender', '$in_Charge', '$Derma', '$Program', '$Pegawai_D')";
		$result2 = mysqli_query($db, $sql2);
		
		if($result2){
		   echo "<script language='Javascript'> 
		   alert('data submitted successfully');
		   </script>";
		}
		else{
		     die('Error: ' . mysqli_error($db));
		}
		
		
		
		
	//$lastId = mysqli_insert_id($db);
			
	}}
?>	
</body>

</html>
<html>
	<head>
	<title>Add Donations</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
	<h1 class="header text-center">Donation Form</h1>
	         
	        <div>
	            <form method="post" action="add_donation.php">

		<?php echo display_error(); ?>
		<div>
	        <?php if($Region == "CM000"){?>
		    <a class="btn btn-danger btnAdd" href="index.php">Back</a>  
		    <?php } else { ?>
		    <a class="btn btn-danger btnAdd" href= <?php echo $Region.".php" ?>>Back</a> 
		    <?php } ?>
	        </div>
	       <br>
		<div class="input-group">
			<label>Name</label>
			<input type="text" name="Name" value="<?php echo stripslashes($Name);?>">
		</div>
		<div class="input-group">
			<label>Acc. Name</label>
			<input type="text" name="acc_Name" value="<?php echo stripslashes($acc_Name);?>">
		</div>
		<div class="input-group">
			<label>KP(123456-12-1234)</label>
			<input type="text" name="KP" value="<?php echo $KP;?>">
		</div>
		<div class="input-group">
			<label>Acc. No(1234-1234-123456)</label>
			<input type="text" name="acc_No" value="<?php echo $acc_No;?>">
		</div>
	<div class="input-group">
			<label>Bank</label>
			<select name="Bank" id="Bank" >
				<option value=""></option>
				<option value="02-Bank Rakyat Berhad" <?php if ($Bank == "02-Bank Rakyat Berhad"){echo 'selected="selected"';}?>>02-Bank Rakyat Berhad</option>
				<option value="04-Bangkok Bank Berhad" <?php if ($Bank == "04-Bangkok Bank Berhad"){echo 'selected="selected"';}?>>04-Bangkok Bank Berhad</option>
				<option value="07-Bank of America" <?php if ($Bank == "07-Bank of America"){echo 'selected="selected"';}?>>07-Bank of America</option>
				<option value="08-AmBank Berhad" <?php if ($Bank == "08-AmBank Berhad"){echo 'selected="selected"';}?>>08-AmBank Berhad</option>
				<option value="10-Bank Simpanan Nasional Berhad" <?php if ($Bank == "10-Bank Simpanan Nasional Berhad"){echo 'selected="selected"';}?>>10-Bank Simpanan Nasional Berhad</option>
				<option value="12-Alliance Bank Berhad" <?php if ($Bank == "12-Alliance Bank Berhad"){echo 'selected="selected"';}?>>12-Alliance Bank Berhad</option>
				<option value="14-Standard Chartered Bank Berhad" <?php if ($Bank == "14-Standard Chartered Bank Berhad"){echo 'selected="selected"';}?>>14-Standard Chartered Bank Berhad</option>
				<option value="17-Citibank" <?php if ($Bank == "17-Citibank"){echo 'selected="selected"';}?>>17-Citibank</option>
				<option value="18-RHB Bank Berhad" <?php if ($Bank == "18-RHB Bank Berhad" || $Bank == "18-RHB Bank"){echo 'selected="selected"';}?>>18-RHB Bank Berhad</option>
				<option value="19-Deustche Bank (M) Bhd" <?php if ($Bank == "19-Deustche Bank (M) Bhd"){echo 'selected="selected"';}?>>19-Deustche Bank (M) Bhd</option>
				<option value="22-HSBC Bank Berhad" <?php if ($Bank == "22-HSBC Bank Berhad"){echo 'selected="selected"';}?>>22-HSBC Bank Berhad</option>
				<option value="24-Hong Leong Bank Berhad/Hong Leong Finance" <?php if ($Bank == "24-Hong Leong Bank Berhad/Hong Leong Finance"||$Bank == "24-Hong Leong Bank Berhad/ Hong Leong Finance" || $Bank == "24-Hong Leong Bank Berhad Hong Leong Finance"){echo 'selected="selected"';}?>>24-Hong Leong Bank Berhad/ Hong Leong Finance</option>
				<option value="26-United Overseas Bank (M) Bhd" <?php if ($Bank == "26-United Overseas Bank M Bhd" || $Bank == "26-United Overseas Bank (M) Bhd"){echo 'selected="selected"';}?>>26-United Overseas Bank (M) Bhd</option>
				<option value="27-Malayan Banking Berhad" <?php if ($Bank == "27-Malayan Banking Berhad"){echo 'selected="selected"';}?>>27-Malayan Banking Berhad</option>
				<option value="29-OCBC Bank Berhad" <?php if ($Bank == "29-OCBC Bank Berhad"){echo 'selected="selected"';}?>>29-OCBC Bank Berhad</option>
				<option value="32-Affin Bank Berhad" <?php if ($Bank == "32-Affin Bank Berhad"){echo 'selected="selected"';}?>>32-Affin Bank Berhad</option>
				<option value="33-Public Bank Berhad/Public Finance Berhad" <?php if ($Bank == "33-Public Bank Berhad/Public Finance Berhad" || $Bank == "33-Public Bank Berhad/ Public Finance Berhad"||$Bank == "33-Public Bank Berhad Public Finance Berhad"){echo 'selected="selected"';}?>>33-Public Bank Berhad/ Public Finance Berhad</option>
				<option value="35-CIMB Bank Berhad" <?php if ($Bank == "35-CIMB Bank Berhad"){echo 'selected="selected"';}?>>35-CIMB Bank Berhad</option>
				<option value="41-Bank Muamalat Malaysia Berhad" <?php if ($Bank == "41-Bank Muamalat Malaysia Berhad"){echo 'selected="selected"';}?>>41-Bank Muamalat Malaysia Berhad</option>
				<option value="42-Bank of China (Malaysia) Berhad" <?php if ($Bank == "42-Bank of China (Malaysia) Berhad"){echo 'selected="selected"';}?>>42-Bank of China (Malaysia) Berhad</option>
				<option value="45-Bank Islam Malaysia Berhad" <?php if ($Bank == "45-Bank Islam Malaysia Berhad"){echo 'selected="selected"';}?>>45-Bank Islam Malaysia Berhad</option>
				<option value="46-The Royal Bank of Scotland" <?php if ($Bank == "46-The Royal Bank of Scotland"){echo 'selected="selected"';}?>>46-The Royal Bank of Scotland</option>
				<option value="47-Kuwait Finance House" <?php if ($Bank == "47-Kuwait Finance House"){echo 'selected="selected"';}?>>47-Kuwait Finance House</option>
				<option value="48-JP Morgan Chase" <?php if ($Bank == "48-JP Morgan Chase"){echo 'selected="selected"';}?>>48-JP Morgan Chase</option>
				<option value="49-Agro Bank" <?php if ($Bank == "49-Agro Bank"){echo 'selected="selected"';}?>>49-Agro Bank</option>
				<option value="51-Sumitomo Misui Banking Corporation (M) Bhd" <?php if ($Bank == "51-Sumitomo Misui Banking Corporation (M) Bhd"){echo 'selected="selected"';}?>>51-Sumitomo Misui Banking Corporation (M) Bhd</option>
				<option value="52-Bank of Tokyo-Mitsubishi UFJ(Malaysia) Berhad" <?php if ($Bank == "52-Bank of Tokyo-Mitsubishi UFJ(Malaysia) Berhad"){echo 'selected="selected"';}?>>52-Bank of Tokyo-Mitsubishi UFJ(Malaysia) Berhad</option>
				<option value="53-Al-Rajhi Banking and Investment Corporation (Malaysia) Berhad" <?php if ($Bank == "53-Al-Rajhi Banking and Investment Corporation (Malaysia) Berhad"){echo 'selected="selected"';}?>>53-Al-Rajhi Banking and Investment Corporation (Malaysia) Berhad</option>
				<option value="59-Indust & Comm Bank of China (M) Berhad" <?php if ($Bank == "59-Indust & Comm Bank of China (M) Berhad"){echo 'selected="selected"';}?>>59-Indust & Comm Bank of China (M) Berhad</option>
				<option value="60-BNP Paribas (M) bhd/ BNP Paribas (Islamic)" <?php if ($Bank == "60-BNP Paribas (M) bhd/ BNP Paribas (Islamic)"){echo 'selected="selected"';}?>>60-BNO Paribas (M) bhd/ BNP Paribas (Islamic)</option>
				<option value="73-Mizuho Bank" <?php if ($Bank == "73-Mizuho Bank"){echo 'selected="selected"';}?>>73-Mizuho Bank</option>
				<option value="75-MBSB" <?php if ($Bank == "75-MBSB"){echo 'selected="selected"';}?>>75-MBSB</option>
				<option value="IKBS TAHUNAN" <?php if ($Bank == "IKBS TAHUNAN"){echo 'selected="selected"';}?>>IKBS TAHUNAN</option>
				<option value="TAHUNAN" <?php if ($Bank == "TAHUNAN"){echo 'selected="selected"';}?>>TAHUNAN</option>
				<option value="MENINGGAL DUNIA" <?php if ($Bank == "MENINGGAL DUNIA"){echo 'selected="selected"';}?>>MENINGGAL DUNIA</option>
			</select>
		</div>
			<div class="input-group">
			<label>Add1</label>
			<input type="text" name="Add1" value="<?php echo stripslashes($Add1);?>">
		</div>
		<div class="input-group">
			<label>Add2</label>
			<input type="text" name="Add2" value="<?php echo stripslashes($Add2);?>">
		</div>
		<div class="input-group">
			<label>Poscode</label>
			<input type="text" name="Poscode" value="<?php echo $Poscode;?>">
		</div>
		<div class="input-group">
			<label>Town</label>
			<input type="text" name="Town" value="<?php echo stripslashes($Town);?>">
		</div>
		<div class="input-group">
			<label>State</label>
			<select name="State" id="State" >
				<option value=""></option>
				<option value="AUSTRALIA" <?php if ($State == "AUSTRALIA" || $State == "Australia"){echo 'selected="selected"';}?>>AUSTRALIA</option>
				<option value="BRUNEI" <?php if ($State == "BRUNEI" || $State == "Brunei"){echo 'selected="selected"';}?>>BRUNEI</option>
				<option value="JOHOR" <?php if ($State == "JOHOR" || $State == "Johor"){echo 'selected="selected"';}?>>JOHOR</option>
				<option value="KEDAH" <?php if ($State == "KEDAH" || $State == "KEDAH" ){echo 'selected="selected"';}?>>KEDAH</option>
				<option value="KELANTAN" <?php if ($State == "KELANTAN" || $State == "Kelantan"){echo 'selected="selected"';}?>>KELANTAN</option>
				<option value="KUALA LUMPUR" <?php if ($State == "KUALA LUMPUR" || $State == "Kuala Lumpur"){echo 'selected="selected"';}?>>KUALA LUMPUR</option>
				<option value="LABUAN" <?php if ($State == "LABUAN" || $State == "Labuan"){echo 'selected="selected"';}?>>LABUAN</option>
				<option value="MELAKA" <?php if ($State == "MELAKA" || $State == "Melaka"){echo 'selected="selected"';}?>>MELAKA</option>
				<option value="NEGERI SEMBILAN" <?php if ($State == "NEGERI SEMBILAN" || $State == "Negeri Sembilan"){echo 'selected="selected"';}?>>NEGERI SEMBILAN</option>
				<option value="PAHANG" <?php if ($State == "PAHANG" || $State == "Pahang" ){echo 'selected="selected"';}?>>PAHANG</option>
				<option value="PERAK" <?php if ($State == "PERAK" || $State == "Perak"){echo 'selected="selected"';}?>>PERAK</option>
				<option value="PERLIS" <?php if ($State == "PERLIS" || $State == "Perlis"){echo 'selected="selected"';}?>>PERLIS</option>
				<option value="PULAU PINANG" <?php if ($State == "PULAU PINANG" || $State == "Pulai Pinang"){echo 'selected="selected"';}?>>PULAU PINANG</option>
				<option value="PUTRAJAYA" <?php if ($State == "PUTRAJAYA" || $State == "Putrajaya"){echo 'selected="selected"';}?>>PUTRAJAYA</option>
				<option value="SABAH" <?php if ($State == "SABAH" || $State == "Sabah"){echo 'selected="selected"';}?>>SABAH</option>
				<option value="SARAWAK" <?php if ($State == "SARAWAK" || $State == "Sarawak"){echo 'selected="selected"';}?>>SARAWAK</option>
				<option value="SELANGOR" <?php if ($State == "SELANGOR" || $State == "Selangor"){echo 'selected="selected"';}?>>SELANGOR</option>
				<option value="SINGAPURA" <?php if ($State == "SINGAPURA" || $State == "Singapura"){echo 'selected="selected"';}?>>SINGAPURA</option>
				<option value="TERENGGANU" <?php if ($State == "TERENGGANU" || $State == "Terengganu"){echo 'selected="selected"';}?>>TERENGGANU</option>	
			</select>
		</div>
		<div class="input-group">
			<label>Phone No(012-3456789)</label>
			<input type="Text" name="phone_No" value="<?php echo $phone_No;?>">
		</div>
	
		<div class="radio_group">
			<label>Gender</label>
			<br>
			<input type="radio" value="Lelaki"  <?php if ($Gender == "LELAKI" ||$Gender == "Lelaki"){echo 'checked="checked"';}?> name="Gender">
			<label for="Lelaki">LELAKI</label><br>
			<input type="radio" value="Perempuan" <?php if ($Gender == "PEREMPUAN"||$Gender == "Perempuan"){echo 'checked="checked"';}?> name="Gender">
			<label for="Perempuan">PEREMPUAN</label>
		</div>
				<div class="input-group">
			<label>Wang Derma</label>
			<input type="text" name="Derma" value="Wang Derma">
		</div>
		<div class="input-group">
			<label>Program</label>
			<input type="text" name="Program" value="PAKP (Program Derma Ayam PAKKP)">
		</div>
		
		<div class="input-group">
			<label>Tarikh Terima Borang Derma</label>
			<input type="date" name="receipt_Date" value="<?php echo $date;?>">
	
		<div class="input-group">
			<label>Que</label>
			<input type="number" name="Que" value="<?php echo $Que;?>">
		</div>
		<div class="input-group">
			<label>Donation</label>
			<select name="Donation" id="Donation" >
				<option value=""></option>
				<option value="250" <?php if ($Donation == "250"){echo 'selected="selected"';}?>>RM250</option>
				<option value="1000" <?php if ($Donation == "1000"){echo 'selected="selected"';}?>>RM1000</option>
				<option value="5000" <?php if ($Donation == "5000"){echo 'selected="selected"';}?>>RM5000</option>
				<option value="10000" <?php if ($Donation == "10000"){echo 'selected="selected"';}?>>RM10000</option>
				<option value="25000" <?php if ($Donation == "25000"){echo 'selected="selected"';}?>>RM25000</option>
				<option value="100000" <?php if ($Donation == "100000"){echo 'selected="selected"';}?>>RM100000</option>
			</select>
		</div>
		<div class="input-group">
			<label>Ref</label>
			<input type="text" name="Ref" value="<?php echo $Ref;?>">
		</div>
			<div class="input-group">
			<label>Wakil</label>
			<input type="text" name="Wakil" value="<?php echo $Region;?>">
		</div>
		    <div class="input-group">
			<label>Person Incharge</label>
			<input type="text" name="in_Charge" value="<?php echo stripslashes($in_Charge);?>">
		</div>
        <input type="hidden" name="Pegawai_D" value="<?php echo $fullName;?>">
        <input type="hidden" name="id" value="<?php echo $id;?>">
		<div class="input-group">
		    <?php if($Region == "CM000"){?>
		    <a class="btn btn-danger btnAdd" href="index.php">Back</a>  
		    <?php } else { ?>
		    <a class="btn btn-danger btnAdd" href= <?php echo $Region.".php" ?>>Back</a> 
		    <?php } ?>
			<button type="submit" class="btn" name="Donate_btn">Donate</button>
		</div>
		
	</form>
	        </div>
        
	   
	</body>
</html>
