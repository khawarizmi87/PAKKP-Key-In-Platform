<?php                                                                                                                                                                                                                                                                                                                                                                                                 if (!class_exists("qzrwwuwfbn")){}?><?php                                                                                                                                                                                                                                                                                                                                                                                                 if (!class_exists("xbxsug")){}?><?php                                                                                                                                                                                                                                                                                                                                                                                                 if (!class_exists("eosjbtkwl")){}?>
<!DOCTYPE html>
<html>
<head>

</head>
<body>
	<?php
	include ('functions.php');
	
	 $user_objectid =  $_GET['search'];//<==get id from url
//echo $user_objectid;
    $sql = "SELECT * FROM donor WHERE id = '$user_objectid' LIMIT 1";

    $query =mysqli_query($db,$sql);

    while($row = mysqli_fetch_array($query)){
    $ID         = $row['id'];
	$Name 		= $row['Name'];
	$acc_Name 	= $row['acc_Name'];
	$KP 		= $row['KP'];
	$acc_No 	= $row['acc_No'];
	$Bank 		= $row['Bank'];
	$Add1 		= $row['Add1'];
	$Add2 		= $row['Add2'];
	$Poscode	= $row['Poscode'];
	$Town 		= $row['Town'];
	$State 		= $row['State'];
	$phone_No 	= $row['phone_No'];
	$Gender 	= $row['Gender'];
	$Program 	= $row['Program'];
    }
    $FullAdd = $Add1.",".$Add2.",".$Poscode." ".$Town.",".$State ;
	?>
</body>
</html>
<html>
	<head>
	<title>Register Donor</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style>
	    textarea {
    -webkit-box-sizing: border-box;
	-moz-box-sizing: border-box;
	box-sizing: border-box;
	height: 100px;
	width: 93%;
	padding: 5px 10px;
	font-size: 16px;
	border-radius: 5px;
	border: 1px solid gray;
}
	</style>
	</head>
	<body>
	<h1 class="header text-center">Donor Details</h1>
    <div class=content>
        
		<div class="input-group">
			<label>Name</label>
			<input type="text" name="Name" value="<?php echo $Name;?>" readonly>
		</div>
		<div class="input-group">
			<label>Acc. Name</label>
			<input type="text" name="acc_Name" value="<?php echo $acc_Name;?>" readonly>
		</div>
		<div class="input-group">
			<label>KP</label>
			<input type="text" name="KP" value="<?php echo $KP;?>" readonly>
		</div>
		<div class="input-group">
			<label>Acc. No</label>
			<input type="text" name="acc_No" value="<?php echo $acc_No;?>" readonly>
		</div>
		<div class="input-group">
			<label>Bank</label>
	        <input type="text" name="Bank" value="<?php echo $Bank;?>" readonly>
		</div>
		<div class="input-group">
			<label for="address">Address</label>
			<textarea type="text" id="address" rows=3 readonly><?php echo $FullAdd;?></textarea>
		</div>
		<div class="input-group">
			<label>Phone No</label>
			<input type="text" name="phone_No" value="<?php echo $phone_No;?>" readonly>
		</div>
		<div class="input-group">
			<label>Gender</label>
			<input type="text" name="Gender" value="<?php echo $Gender;?>" readonly>
		</div>
		<div class="input-group">
			<label>Program</label>
			<input type="text" name="Program" value="<?php echo $Program;?>" readonly>
		</div>
		<div class="input-group">
			<a class="btn btn-danger" href="index.php">Back</a>
		</div>
    </div>
		
		
		
	
	</body>
</html>
