<?php
include ('functions.php');
$Region=getRegion();
$user_objectid =  $_GET['id'];//<==get id from url

$sql = "SELECT `Submission date`,Que,Donation,Rujukan,`Pegawai Data` FROM donation WHERE DONORID = '$user_objectid'";
$result = mysqli_query($db,$sql);// or die(mysqli_error($db));  
$rows = mysqli_num_rows($result);
?>
<!doctype html>
<html>
<head>    
    <title>Viewpage</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>
.btnAdd {
      text-align: left;
      width: 90%;
      margin-bottom: 20px;
    }
.center{
	  margin-left: auto;
  margin-right: auto;
}
.tableDon{
   width:100%;
   font-size: 25px;
}
</style>
<body>
<div class="header">
	<h2>Donation List</h2>
</div>
<div class="container-fluid content">
	<div class="card "col-md-8 table-responsive" >
		<div class="btnAdd">
		<?php if($Region == "CM000"){?>
		    <a class="btn btn-danger btnAdd" href="index.php">Back</a>  
		    <?php } else { ?>
		    <a class="btn btn-danger btnAdd" href= <?php echo $Region.".php" ?>>Back</a> 
		    <?php } ?>
        </div>
		<table class="table center tableDon">
				<thead style="text-align: left" bgcolor=#5F9EA0>
					<tr>
					<th>Que</th>
					<th>Reference</th>
					<th>Donation</th>
					<th>Entry Date</th>
					<th>Data Officer</th>
					<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						if($rows){
					while($res = mysqli_fetch_array($result)) { 
					?>
					<tr>
					<td><?php echo $res['Que']; ?></td>
					<td><?php echo $res['Rujukan']; ?></td>
					<td><?php echo "RM".$res['Donation'];?></td> 
					<td><?php echo $res['Submission date'];?></td>  
					<td><?php echo $res['Pegawai Data'];?></td>  
					<td><a href="edit_donation.php?id=<?php echo $res['Rujukan'];?>"  class="btn btn-success btn-sm " >Update</a></td>  
					</tr>        
					<?php }
					} 
					else{ ?>
					<tr>
					 <td><strong><?php echo "No Records Found"; ?></strong></td>
					</tr>
					<?php	}
					?>
				</tbody>
		</table>
	</div>	
</div>
</body>
</html>