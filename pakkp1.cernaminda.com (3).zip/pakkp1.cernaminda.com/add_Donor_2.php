<?php
include ('functions.php');
include 'connection.php';

		$fname = $_SESSION['user']['firstName'];
	$lname = $_SESSION['user']['lastName'];
	$fullName = $fname." ".$lname;
?>

<!DOCTYPE html>
<html>
<head>

</head>
<body>
	<?php
	
	if (isset($_POST['add_btn'])){
	
	$KP = isset($_POST['KP']) ? $_POST['KP'] : '';
	
	$query = mysqli_query($conn, "SELECT * FROM donor WHERE KP='".$KP."'");

        if (!$query)
        {
            die('Error: ' . mysqli_error($conn));
        }
    
    if(mysqli_num_rows($query) > 0){
    
        $host  = $_SERVER['HTTP_HOST'];
        $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        $extra = 'add_Donor_3.php?KP='.$KP.'&userid='.$fullName;
    
        echo "<script language='Javascript'>
        alert('ID Number already registered. Next Process');
        location.href='https://$host$uri/$extra'
        </script>";
    
    }else{
    
        $host  = $_SERVER['HTTP_HOST'];
        $uri   = rtrim(dirname($_SERVER['PHP_SELF']), '/\\');
        $extra = 'add_Donor.php?id='.$KP;
    
        echo "<script language='Javascript'>
        alert('New Donor. Please Enter Donor Details In Next Page');
        location.href='https://$host$uri/$extra'
        </script>";
    
    }
	
	
	
	}
	?>
</body>

</html>
<html>
	<head>
	<title>New Register : Donor</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	</head>
	<body>
	<h1 class="header text-center">New Registration : Donor</h1>
		<form method="post" method="POST" action="add_Donor_2.php">

		<?php echo display_error(); ?>


		<div class="input-group">
			<label>ID Number : </label>
			<input type="text" name="KP" id="KP" placeholder="Please Insert Donor ID Number (with '-')" maxlength="14">
		</div>

		<div class="input-group">
		    <a class="btn btn-info btn-sm" href="index.php">Back</a> 
			<button type="submit" class="btn btn-danger btn-sm" name="add_btn" >Check Donor Data</button>
		</div>
	</form>
		
		</div>
	</body>
</html>
