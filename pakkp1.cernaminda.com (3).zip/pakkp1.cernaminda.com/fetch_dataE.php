<?php include('functions.php');

$fullName=getFullName();

$output= array();
$sql = "SELECT `ID`,`Submission date`,`Name`,`KP`,`No.Acc`,`Bank`,`Donation`,`Rujukan`,`Wakil` FROM `donation` WHERE `Pegawai Data` like '%".$fullName."%' AND `Wakil` = 'E001'";
$totalQuery = mysqli_query($db,$sql);
$total_all_rows = mysqli_num_rows($totalQuery);

/*if(isset($_POST['search']['value']))
{
	$search_value = e($_POST['search']['value']);
	$sql .= " AND (Name like '%".$search_value."%'";
	$sql .= " OR KP like '%".$search_value."%'";
	$sql .= " OR No.Acc like '%".$search_value."%'";
	$sql .= " OR Bank like '%".$search_value."%'";
	$sql .= " OR Rujukan like '%".$search_value."%'";
	$sql .= " OR Wakil like '%".$search_value."%')";
}*/

if(isset($_POST['order']))
{
	$column_name = $_POST['order'][0]['column'];
	$order = $_POST['order'][0]['dir'];
	$sql .= " ORDER BY ".$column_name." ".$order."";
}
else
{
	$sql .= " ORDER BY `Submission date` desc";
}

if($_POST['length'] != -1)
{
	$start = $_POST['start'];
	$length = $_POST['length'];
	$sql .= " LIMIT  ".$start.", ".$length;
}	

$query = mysqli_query($db,$sql);
$count_rows = mysqli_num_rows($query);
$data = array();
while($row = mysqli_fetch_assoc($query))
{
	$sub_array = array();
	$sub_array[] = $row['Submission date'];
	$sub_array[] = $row['Name'];
	$sub_array[] = $row['KP'];
	$sub_array[] = $row['No.Acc'];
	$sub_array[] = $row['Bank'];
	$sub_array[] = $row['Rujukan'];
	$sub_array[] = "RM".$row['Donation'];
	$sub_array[] = $row['Wakil'];
	$sub_array[] = '<a href="edit_donation.php?id='.$row['Rujukan'].'"  class="btn btn-success btn-sm " >Edit</a>';
	$data[] = $sub_array;
}

$output = array(
	'draw'=> intval($_POST['draw']),
	'recordsTotal' =>$count_rows ,
	'recordsFiltered'=>   $total_all_rows,
	'data'=>$data,
);
echo  json_encode($output);
?>