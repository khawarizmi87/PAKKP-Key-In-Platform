<?php

 
	include('functions.php');
	if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header("Location: login.php");
	die();
	}
	if( $_SESSION['user']['Region']!= "E001"){
	$_SESSION['user']['Region'] = E001;  
	}
	
	$id = $_SESSION['user']['id'];
	$fullName=getFullName();
//	if( $_SESSION['user']['Region']!= "CM000"){
//	    $_SESSION['user']['Region']= "CM000";//
//	};
	

    
	
	if (isset($_POST['Export'])){
		
	/*	$from_date 			= date('Y-m-d', strtotime($_POST['from_date']));
		$to_date 			= date('Y-m-d', strtotime($_POST['to_date']));
		if($from_date == '00/00/0000')
		{
			array_push($errors,"BEGINNING DATE IS NOT ENTERED");
		}
		if($to_date == '00/00/0000')
		{
			array_push($errors,"END DATE IS NOT ENTERED");
		}
		if (count($errors) == 0)*/
		//{
		    $query = "SELECT * FROM donation"; 
				//	WHERE `Submission date` >= '".$from_date."' AND `Submission date` <= '".$to_date."' ORDER BY ID ASC";
			$result = mysqli_query($db,$query) or die(mysqli_error($db));			
			$file_name = 'PAKP Donation '.date('Ymd').'.csv';
			$file = fopen($file_name,"w");
			// Header row - Remove this code if you don't want a header row in the export file.
			$header = array( "ID", "Submission date","Tarikh Terima Borang Sukarelawan","Name","Account Name","KP","Que", "Donation", "Rujukan", "No.Acc", "Bank", "Add 1", "Add 2", "Poscode", "Town", "State", "Telefon", "Wakil", "Gender", "Person Incharge", "Wang Derma","Ref", "Pegawai Data" ); 
			fputcsv($file,$header); 

			while($row = mysqli_fetch_assoc($result)){
			$id = $row['ID'];
			$entry_date = $row['Submission date'];
			$receipt_date = $row['Tarikh Terima Borang Sukarelawan'];
			$name = $row['Name'];
			$acc_name = $row['Account Name'];
			$KP = $row['KP'];
			$Que = $row['Que'];
			$donation = $row['Donation'];
			$Ref = $row['Rujukan'];
			$acc_no = $row['No.Acc'];
			$Bank = $row['Bank'];
			$Add1 = $row['Add 1'];
			$Add2 = $row['Add 2'];
			$Poscode = $row['Poscode'];
			$Town = $row['Town'];
			$State = $row['State'];
			$phone_no = $row['Telefon'];
			$wakil = $row['Wakil'];
			$gender = $row['Gender'];
			$incharge = $row['Person Incharge'];
			$derma = $row['Wang Derma'];
			$program = $row['Ref'];
			$P_data = $row['Pegawai Data'];

			// Write to file 
			$donationData = array($id,$entry_date,$receipt_date,$name,$acc_name,$KP,$Que,$donation,$Ref,$acc_no,$Bank,$Add1,$Add2,$Poscode,$Town,$State,$phone_no,$wakil,$gender,$incharge,$derma,$program,$P_data);
			fputcsv($file, $donationData); 
		
			}
		header("Content-Description: File Transfer");
		header("Content-Disposition: attachment; filename=$file_name");
		header("Content-Type: application/csv;");	
		readfile($file_name);
		fclose($file);
		exit;
	}
	//}
	

?>
<!doctype html>
<html lang="en">
<?php if (!isAdmin()) { ?>
<head>
	<title>Donor Search</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<style type="text/css">
    .btnAdd {
      text-align: right;
      width: 91.5%;
      margin-bottom: 20px;
	  margin-top: 10px;
    }
  </style>
	</head>
	<body>
	  <div><h1 class="header text-center">Donor Search</h1>
	     
		<form method="post" method="POST" action="index.php">
        
		<div class="input-group">
			<button type="submit" class="btn btn-danger btn-sm" name="Search_btn" >Check Donor Data</button>
		</div>
	</form>
	<div class="btnAdd">
		<a href="index.php?logout='1'" data-id="" class="btn btn-danger btn-sm" style="color: white; flex: right" >Logout</a>
       </div>
	</div>
	</body>
<?php } else { ?>
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/jq-3.6.0/dt-1.11.3/datatables.min.css"/>
 
	
   
    <title>Donor List</title>
	<style type="text/css">
    .btnAdd {
      text-align: right;
      width: 91.5%;
      margin-bottom: 20px;
	  margin-top: 10px;
    
    .card {
        width: 80;
        background:#F8F8FF;
    }
    .welcome {
        font-size: 20px;
        color: white;
    }
	.insertdate{
		margin-bottom: 10px;
		margin-left: 130px;
	}
  </style>
  </head>
  <body>
     <div style="background:#5F9EA0;">
	<h1 class="text-center"style="padding: 20px 0px 0px 0px;"><?php echo $_SESSION['user']['Region'] ; ?></h1>
	<!--<p class="datatable design text-center welcome">Welcome, <?php echo $fullName; ?> </p>-->
   <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand" style="padding-left: 60px;">PAKP</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav  ">
      <a class="nav-item nav-link" href="index.php">CM</a>
      <a class="nav-item nav-link" href="A001.php">Region A</a>
      <a class="nav-item nav-link" href="C001.php">Region C</a>
      <a class="nav-item nav-link active bg-success" href="E001.php">Region E</a>
      <a class="nav-item nav-link" href="L001.php">Region L</a>
      <a class="nav-item nav-link" href="M001.php">Region M</a>
    </div>
  </div>
</nav>
	<div class="container-fluid">
		<div class="card">
		<div class="btnLogout">
		
		</div>
		<div class="btnAdd">
		<a href="index.php?logout='1'" data-id="" class="btn btn-danger btn-sm" style="color: white;">Logout</a>
		<a href="history.php" data-id="" class="btn btn-warning btn-sm">History</a>
         <a href="add_Donor_2.php" data-id="" class="btn btn-info btn-sm">Insert New Data</a>
         <a href="add_Donor.php" data-id="" class="btn btn-success btn-sm" >Add Donor</a>
       </div>
<!--<form method='post' action='index.php'>-->

     <!-- Datepicker -->
<!--	 <label>From</label>-->
<!--     <input type='date' class='datepicker' placeholder="From date" name="from_date" id='from_date' >-->
<!--	 <label>Till</label>-->
<!--     <input type='date' class='datepicker' placeholder="To date" name="to_date" id='to_date' >-->

    <!--  Export button 
<input type='submit' class = "btn btn-primary btn-md"value='Export' name='Export'>
</form> -->
   <?php echo display_error(); ?>
		<div class="row">
			<div class="col-md-1" ></div>
			<div class="col-md-10 table-responsive">
				<table id="datatable" class="table table-striped" style="width:100%">
					<thead class="thead-dark">
						<th>Name</th>
						<th>KP</th>
						<th>Acc.Num</th>
						<th>Bank</th>
						<th>Action</th>
					</thead>
					<!--<tbody>
						<th>Name</th>
						<th>KP</th>
						<th>Acc.Num</th>
						<th>Bank</th>
						<th>Action</th>
					</tbody>-->
				</table>
			</div>
			<div class="col-md-1"></div>
		
		</div>
	</div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/v/bs5/jq-3.6.0/dt-1.11.3/datatables.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#datatable').DataTable({
				'serverSide':true,
				'processing': true,
				'paging': true,
				'ordering': false,
				'order': [],
				'ajax':{
					'url': 'fetch_data.php',
					'type': 'post', 
				},
				"fnCreateRow":function(nRow, aData,iDataIndex)
				{
					$(nRow).attr('id',aData[2]);
				},
				'columnDefs':[{
					'target': [0,5],
					'orderable': false,
				}]
			});
		});

	</script>
</div>
</div>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
<?php  } ?>
</html>