<?php

 
	include('functions.php');
	if (!isLoggedIn()) {
	$_SESSION['msg'] = "You must log in first";
	header("Location: login.php");
	die();
	}
	if(!isAdmin()){
	header("Location: admin/index.php");  
	}
	$Region=getRegion();
	$id = $_SESSION['user']['id'];
	$fullName=getFullName();

?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs5/jq-3.6.0/dt-1.11.3/datatables.min.css"/>
 
	
   
    <title>Donor List</title>
	<style type="text/css">
    .btnAdd {
      text-align: right;
      width: 91.5%;
      margin-bottom: 20px;
	  margin-top: 10px;
    }
    .card {
        width: 80;
        background:#F8F8FF;
    }
    .welcome {
        font-size: 20px;
        color: white;
    }
	.insertdate{
		margin-bottom: 10px;
		margin-left: 130px;
	}
  </style>
  </head>
  <body>
     <div style="background:#5F9EA0;">
	<h1 class="text-center"style="padding: 20px 0px 0px 0px;">History Log</h1>
	<p class="datatable design text-center welcome">Welcome, <?php echo $fullName; ?> </p>
	<div class="container-fluid">
		<div class="card">
		<div class="btnLogout">
		
		</div>
		<div class="btnAdd">
		    <?php if($Region == "CM000"){?>
		    <a class="btn btn-info btn-sm" href="index.php">HOME</a>  
		    <?php } else { ?>
		    <a class="btn btn-info btn-sm" href= <?php echo $Region.".php" ?>>HOME</a> 
		    <?php } ?>
		     <a class="btn btn-warning btn-sm" href="historyA001.php">Region A</a>
		    <a class="btn btn-success btn-sm" href="historyC001.php">Region C</a>
		    <a class="btn btn-danger btn-sm" href="historyE001.php">Region E</a>
		    <a class="btn btn-secondary btn-sm" href="historyL001.php">Region L</a>
		    <a class="btn btn-primary btn-sm" href="historyM001.php">Region M</a>
       </div>
   <?php echo display_error(); ?>
		<div class="row">
			<div class="col-md-1" ></div>
			<div class="col-md-10 table-responsive">
				<table id="datatable" class="table table-striped" style="width:100%">
					<thead class="thead-dark">
						<th>Date</th>
						<th>Name</th>
						<th>KP</th>
						<th>Acc.Num</th>
						<th>Bank</th>
						<th>Rujukan</th>
						<th>Donation</th>
						<th>Wakil</th>
						<th>Action</th>
					</thead>
					<!--<tbody>
						<th>Name</th>
						<th>KP</th>
						<th>Acc.Num</th>
						<th>Bank</th>
						<th>Action</th>
					</tbody>-->
				</table>
			</div>
			<div class="col-md-1"></div>
		
		</div>
	</div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
	<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/v/bs5/jq-3.6.0/dt-1.11.3/datatables.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function() {
			$('#datatable').DataTable({
				'serverSide':true,
				'processing': true,
				'searching': false,
				'ordering': false,
				'paging': true,
				'order': [],
				'ajax':{
					'url': 'fetch_data2.php',
					'type': 'post', 
				},
				"fnCreateRow":function(nRow, aData,iDataIndex)
				{
					$(nRow).attr('id',aData[2]);
				},
				'columnDefs':[{
					'target': [0,10],
					'orderable': false,
				}]
			});
		});

	</script>
</div>
</div>
    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
    -->
  </body>
</html>