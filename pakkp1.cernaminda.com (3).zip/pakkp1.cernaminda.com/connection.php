<?php
$dbhost = 'localhost';
$dbuser = 'bwgcommy_pakkp';
$dbpass = 'T1Y~NdSCI]CY';
$dbname = 'bwgcommy_pakkpdb';


//connection to the database
$conn = mysqli_connect($dbhost,$dbuser,$dbpass) or die ("Unable to connect to DBMS");
mysqli_select_db($conn, $dbname);
//echo "Connected to MySQL . This is a connection.php file.<br>";
?>